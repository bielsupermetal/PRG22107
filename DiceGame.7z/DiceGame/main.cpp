#include <iostream>
#include <stdio.h>
#include <time.h>

using namespace std;

class Die{
private:
    int _faceValue;

public:
    Die();
    void roll();
    int getFaceValue();
};

Die::Die(){
    srand (time(NULL));
    roll();
}
void Die::roll(){
    _faceValue = (rand() % 6) +1; //restos possíveis de uma divisão por 6 são de 0 a 5.
}

int Die::getFaceValue(){
    return _faceValue;
}

int main(){
    Die obj;

    obj.roll();

    cout << "Face Value = " << obj.getFaceValue() << endl;

    obj.roll();

    cout << "Face Value = " << obj.getFaceValue() << endl;

    return 0;
}
